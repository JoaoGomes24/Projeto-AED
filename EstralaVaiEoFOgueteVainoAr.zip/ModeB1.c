/*******************************************************************************
* File Name: ModeB1.c
*
* SYNOPSIS
*     #include <stdio.h>
*     #include <stdlib.h>
*     #include <string.h>
*     #include <stdbool.h>
*     #include <float.h>
*     #include <limits.h>
*     #include "AirRoutes.h"
*
* DESCRIPTION
*   Coloca a aresta recebida no cabecalho caso exista a 0
*   e corre o algoritmo de Kruskal de novo(ModoA1) e cria uma nova Mst sem
*   a aresta interditada
*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <float.h>
#include <limits.h>
#include "AirRoutes.h"

/******************************************************************************
* FreeB1()
*
* Arguments: st-B1 - ponteiro que guarda a informacao da Mst criada para o modo B1

* Returns: nao tem

* Description:
* Liberta a Mst criada
*****************************************************************************/
void FreeB1(AirRoutes_B1 *st_B1){

  free(st_B1->mstB1_1);
  free(st_B1->mstB1_2);
  free(st_B1->val_B1);
  free(st_B1);
}

/******************************************************************************
* AllocB1()
*
* Arguments: st_Routes - ponteiro para estrutura que guarda informacao dos grafos

* Returns: st_B1

* Description:
* Aloca a estrutura para a Mst criada para o modo B1
*****************************************************************************/

AirRoutes_B1 *AllocB1(AirRoutes *st_Routes){

  AirRoutes_B1 *st_B1;

  st_B1 = (AirRoutes_B1 *)calloc(1, sizeof(AirRoutes_B1));
  if (st_B1 == NULL){
    exit(0);
  }
  st_B1->mstB1_1 = (int*)calloc(get_nAirport(st_Routes)+1, sizeof(int));
  if (st_B1->mstB1_1 == NULL){
    exit (0);
  }
  st_B1->mstB1_2 = (int*)calloc(get_nAirport(st_Routes)+1, sizeof(int));
  if (st_B1->mstB1_2 == NULL){
    exit (0);
  }
  st_B1->val_B1 = (double*)calloc(get_nAirport(st_Routes)+1, sizeof(double));
  if (st_B1->val_B1 == NULL){
    exit (0);
  }
  return st_B1;
}

/******************************************************************************
* checkExistenceB1()
*
* Arguments: st_Routes - ponteiro para estrutura que guarda informacao dos grafos
            st_Mst - ponteiro para estrutura que guarda informacao da Mst
Write - ponteiro para o ficheiro de saida
* Returns: exist

* Description:
Verifica a existencia da rota interditada.
*****************************************************************************/
int checkExistenceB1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst){
  int i, exist = 0;

  for (i = 1; i < get_nAirport(st_Routes); i++) {
    if(get_mst1(st_Mst, i) != 0){
      if (((get_mst1(st_Mst, i) == get_City1(st_Routes)) && (get_mst2(st_Mst, i) == get_City2(st_Routes))) || ((get_mst2(st_Mst, i) == get_City1(st_Routes)) && (get_mst1(st_Mst, i) == get_City2(st_Routes)))){
        exist = 1;
      }
    }
  }
  return exist;
}

/******************************************************************************
* printMST_B1()
*
* Arguments: st_Routes - ponteiro para estrutura que guarda informacao dos grafos
             st_Mst - ponteiro para estrutura que guarda informacao da Mst
             Write - ponteiro para o ficheiro de saida
             st_B1 - ponteiro que guarda a informacao da Mst criada para o modo B1
             exist -integer que verifica a existencia da rota interditada
             Mode - caso seja 0, faz print da  Mst vinda do modo A1. Caso seja 1,
              faz print da Mst previamente guardada st_B1
* Returns: nao tem

* Description:
*Imprime a Mst do modo B1
*****************************************************************************/
void printMST_B1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst, AirRoutes_B1 *st_B1, int exist, int Mode){

  int j;

  if(((strcmp(get_Mode(st_Routes), "E1")) != 0)){
    fprintf(Write, "%d %d %s %d %d %d %.2lf %d\n", get_nAirport(st_Routes), get_nRoutes(st_Routes), get_Mode(st_Routes), get_City1(st_Routes), get_City2(st_Routes), get_count(st_Mst), get_sum(st_Mst), exist);
    if(Mode == 1){
      for (j = 1; j < get_nAirport(st_Routes); j++) {
        if(get_mstB1_1(st_B1, j) != 0){
          fprintf(Write, "%d %d %.2lf\n", get_mstB1_1(st_B1, j), get_mstB1_2(st_B1, j), get_valB1(st_B1, j));
        }
      }
    }
    if(Mode == 0){
      for (j = 1; j < get_nAirport(st_Routes); j++) {
        if(get_mst1(st_Mst, j) != 0 && get_val(st_Mst, j) != 0){
          fprintf(Write, "%d %d %.2lf\n", get_mst1(st_Mst, j), get_mst2(st_Mst, j), get_val(st_Mst, j));
        }
      }
    }
  }
}

/******************************************************************************
* ModeB1()
*
* Arguments: st_Routes - ponteiro para estrutura que guarda informacao dos grafos
             st_Mst - ponteiro para estrutura que guarda informacao da Mst
             Write - ponteiro para o ficheiro de saida
             st_E1 - ponteiro para a estrutura que guarda a informacao da Mst criada para o modo E1
* Returns: nao tem

* Description:
*Coloca a aresta recebida no cabecalho caso exista a 0
*   e corre o algoritmo de Kruskal de novo(ModoA1) e cria uma nova Mst sem
*   a aresta interditada
*****************************************************************************/
void ModeB1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst, AirRoutes_E1 *st_E1){

  AirRoutes_B1 *st_B1 = NULL;
  int i, j, exist = 0, connectivity = 0;
  int airport1 = 0, airport2 = 0, idx = 0, out = 0;
  double cost = 0.0;

  if(((get_City1(st_Routes) >= 1) && (get_City1(st_Routes) <= get_nAirport(st_Routes)) && (get_City2(st_Routes) >= 1) && (get_City2(st_Routes) <= get_nAirport(st_Routes)))){

    if(((strcmp(st_Routes->Mode, "E1")) != 0)){
      if(get_existense(st_Routes) != 1){
        printMST_B1(Write, st_Routes, st_Mst, NULL, -1, 0);
        fprintf(Write, "\n");
        return;
      }
      exist = checkExistenceB1(Write, st_Routes, st_Mst);
      if(exist == 0 || exist == -1){
        printMST_B1(Write, st_Routes, st_Mst, NULL, exist, 0);
        fprintf(Write, "\n");
        return;
      }
      st_B1 = AllocB1(st_Routes);

      for (i = 1; i < get_nAirport(st_Routes); i++) {
        st_B1->mstB1_1[i] = get_mst1(st_Mst, i);
        st_B1->mstB1_2[i] = get_mst2(st_Mst, i);
        st_B1->val_B1[i] = get_val(st_Mst, i);
      }
    }


    for (i = 0; i < get_nRoutes(st_Routes); i++) {
      if((get_airport1(st_Routes, i) == get_City1(st_Routes) && get_airport2(st_Routes, i) == get_City2(st_Routes)) || (get_airport2(st_Routes, i) == get_City1(st_Routes) && get_airport1(st_Routes, i) == get_City2(st_Routes))){
        if(((strcmp(st_Routes->Mode, "E1")) == 0)){
           airport1 = get_airport1(st_Routes, i);
           airport2 = get_airport2(st_Routes, i);
           cost = get_cost(st_Routes, i);
           idx = i;
        }
        st_Routes->airports[i].airport1 = 0;
        st_Routes->airports[i].airport2 = 0;
        st_Routes->airports[i].cost = 0.0;
        break;
      }
    }

    ModeA1(Write, st_Routes, st_Mst, 0);

    for (i = 1; i < get_nAirport(st_Routes); i++) {
      for (j = 1; j < get_nAirport(st_Routes); j++) {
        if(((strcmp(get_Mode(st_Routes), "B1")) == 0)){
          if((get_mst1(st_Mst, i) == get_mstB1_1(st_B1, j)) && (get_mst2(st_Mst, i) == get_mstB1_2(st_B1, j))){
            break;
          }
        }else{
          if((get_mst1(st_Mst, i) == get_mstE1_1(st_E1, j)) && (get_mst2(st_Mst, i) == get_mstE1_2(st_E1, j))){
            break;
          }
        }
        if((j == get_nAirport(st_Routes)-1) && (get_val(st_Mst, i) != 0)){
          connectivity = 1;

          if(((strcmp(get_Mode(st_Routes), "B1")) == 0)){
            printMST_B1(Write, st_Routes, st_Mst, st_B1, 1, 1);
          }
          fprintf(Write, "%d %d %.2lf", get_mst1(st_Mst, i), get_mst2(st_Mst, i), get_val(st_Mst, i));
          out = 1;
          if(((strcmp(get_Mode(st_Routes), "B1")) == 0)){
            fprintf(Write, "\n");
          }
          break;
        }
      }
      if(out == 1){
        break;
      }
    }

    if (connectivity == 0) {
      if(((strcmp(get_Mode(st_Routes), "B1")) == 0)){
        printMST_B1(Write, st_Routes, st_Mst, st_B1, -1, 1);
      }
      if(((strcmp(get_Mode(st_Routes), "E1")) == 0)){
        fprintf(Write, "-1");
      }
    }

    if(((strcmp(st_Routes->Mode, "E1")) == 0)){
      st_Routes->airports[idx].airport1 = airport1;
      st_Routes->airports[idx].airport2 = airport2;
      st_Routes->airports[idx].cost = cost;
    }
    fprintf(Write, "\n"); 
    if(((strcmp(st_Routes->Mode, "E1")) != 0)){
      FreeB1(st_B1);
    }
  }else{
    printMST_B1(Write, st_Routes, st_Mst, NULL, -1, 0);
    fprintf(Write, "\n");
  }
  return;
}
