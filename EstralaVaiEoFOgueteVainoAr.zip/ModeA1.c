/*****************************************************************************
* File Name: ModeA1.c
*
* SYNOPSIS
*     #include <stdio.h>
*     #include <stdlib.h>
*     #include <string.h>
*     #include <stdbool.h>
*     #include <float.h>
*     #include <limits.h>
*     #include "AirRoutes.h"
*
* DESCRIPTION
*		Implementa o algoritmo de Kruskal e cria uma MST
*
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <float.h>
#include <limits.h>
#include "AirRoutes.h"

/******************************************************************************
* FreeMst()
*
* Arguments: st_Mst - ponteiro para estrutura que guarda informacao da Mst

* Returns: nao tem

* Description:
*   Liberta a Mst criada
*****************************************************************************/
void FreeMst(AirRoutes_Mst *st_Mst){

  free(st_Mst->st);
  free(st_Mst->val);
  free(st_Mst->mst);
  free(st_Mst);
}

/******************************************************************************
* AllocMst()
*
* Arguments: st_Routes - ponteiro para estrutura que guarda informacao dos grafos

* Returns: nao tem

* Description:
*   Aloca a estrutura para a Mst
*****************************************************************************/
AirRoutes_Mst *AllocMst(AirRoutes *st_Routes){

  AirRoutes_Mst *st_Mst;

  st_Mst = (AirRoutes_Mst *)calloc(1, sizeof(AirRoutes_Mst));
  if (st_Mst == NULL){
    exit(0);
  }
  st_Mst->st = (int*)calloc(get_nAirport(st_Routes)+1, sizeof(int));
  if (st_Mst->st == NULL){
    exit (0);
  }
  st_Mst->val = (double*)calloc(get_nAirport(st_Routes)+1, sizeof(double));
  if (st_Mst->val == NULL){
    exit (0);
  }
  st_Mst->mst = (AirRoutes_Edge*)calloc(get_nAirport(st_Routes)+1, sizeof(AirRoutes_Edge));
  if (st_Mst->mst == NULL){
    exit (0);
  }
  return st_Mst;
}

/******************************************************************************
* Find()
*
* Arguments: st_Mst - ponteiro para estrutura que guarda informacao da Mst

* Returns: int

* Description:
*  Algoritmo Find, encontra um parente para a posicao i, utiliza a tecnica de
*  compressao de caminho
*  Encontra uma raiz e coloca-a como parente de i
*****************************************************************************/
int find(AirRoutes_Mst *st_Mst, int i){

  if (st_Mst->st[i] != i){
    st_Mst->st[i]  = find(st_Mst, st_Mst->st[i]);
  }
  return st_Mst->st[i];
}

/******************************************************************************
* Union()
*
* Arguments: st_Mst - ponteiro para estrutura que guarda informacao da Mst
*            airport1 - variavel que tera possibilidade de sofrer uniao
*            airport2 - variavel que tera possibilidade de sofrer uniao
* Returns: nao tem

* Description:
*  Une dois aeroportos, segundo o seu custo
*****************************************************************************/
void Union(AirRoutes_Mst *st_Mst, int airport1, int airport2){
  int airport1_root = find(st_Mst, airport1);
  int airport2_root = find(st_Mst, airport2);

  if (st_Mst->val[airport1_root] < st_Mst->val[ airport2_root]){
    st_Mst->st[airport1_root] =  airport2_root;
  }else if (st_Mst->val[airport1_root] > st_Mst->val[ airport2_root]){
    st_Mst->st[airport2_root] = airport1_root;
  }
  else{
    st_Mst->st[airport2_root] =  airport1_root;
  }

  return;
}

/******************************************************************************
* getSum()
*
* Arguments: st_Routes - ponteiro para estrutura que guarda informacao dos grafos
*            st_Mst - ponteiro para estrutura que guarda informacao da Mst

* Returns: nao tem

* Description:
*   Esta funcao obtem a soma dos custos das rotas presentes na Mst
*****************************************************************************/
void getSum(AirRoutes *st_Routes, AirRoutes_Mst *st_Mst){
  int i;

  for (i = 1; i < get_nAirport(st_Routes); i++){
    if ((get_mst1(st_Mst, i) != 0) && get_val(st_Mst, i) != get_val(st_Mst, i-1)) {
      st_Mst->sum += get_val(st_Mst, i);
    }
  }
}

/******************************************************************************
* printMST()
*
* Arguments: st_Routes - ponteiro para estrutura que guarda informacao dos grafos
*            st_Mst - ponteiro para estrutura que guarda informacao da Mst
*            Mode - Caso seja modo B1 recebe Mode=0 e não faz a soma na nova Mst
* Returns: nao tem
* Description:
*   Faz print da Mst
*****************************************************************************/
void printMST(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst, int Mode){
  int j;

  qsort(st_Mst->mst, get_nAirport(st_Routes), sizeof(st_Mst->mst[0]), CompareAirports);
  partialSort(st_Routes, st_Mst);

if(Mode == 1){
  getSum(st_Routes, st_Mst);
}

if(((strcmp(st_Routes->Mode, "A1")) == 0)){
  fprintf(Write, "%d %d %s %d %.2lf\n", get_nAirport(st_Routes), get_nRoutes(st_Routes), get_Mode(st_Routes), get_count(st_Mst), get_sum(st_Mst));

  for (j = 1; j < get_nAirport(st_Routes); j++) {
    if(get_mst1(st_Mst, j) != 0){
      fprintf(Write, "%d %d %.2lf\n", get_mst1(st_Mst, j), get_mst2(st_Mst, j), get_val(st_Mst, j));
    }
  }
  fprintf(Write, "\n");
}
}

/******************************************************************************
* ModoA1()
*
* Arguments: st_Routes - ponteiro para estrutura que guarda informacao dos grafos
*            st_Mst - ponteiro para estrutura que guarda informacao da Mst
*            Write - ponteiro para o ficheiro de saida
*            Mode - inteiro que verifica a necessidade de atualizar
*            as variaveis soma e cont acerca da Mst criada, só as atualiza
*            nos modos C1 e no A1 quando é chamado pela primeira vez

* Returns: nao tem

* Description:
*   Implementa o algoritmo de Kruskal
*****************************************************************************/
void ModeA1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst, int Mode){

  int i, v = 1, airport1 = 0, airport2 = 0;

  for (i = 0; i <= get_nAirport(st_Routes); i++){
    st_Mst->st[i] = i;
    st_Mst->val[i] = 0;
    st_Mst->mst[i].cost = 0;
  }

  i = 0;

  while (v < get_nAirport(st_Routes) && i < get_nRoutes(st_Routes)){
    AirRoutes_Edge Next_Edge = st_Routes->airports[i++];
    airport1 = find(st_Mst, Next_Edge.airport1);
    airport2 = find(st_Mst, Next_Edge.airport2);

    if(airport1 != airport2){
      st_Mst->mst[v++] = Next_Edge;
      if(Mode == 1){
        if(((strcmp(st_Routes->Mode, "C1")) == 0)){
          if((get_val(st_Mst, v-1) != 0)){
            st_Mst->count++;
          }
        }else{
          if((get_mst1(st_Mst, v-1) != 0)){
            st_Mst->count++;
          }
        }
      }
      Union(st_Mst, airport1, airport2);
    }
  }
  printMST(Write, st_Routes, st_Mst, Mode);
  return;
}
