#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "AirRoutes.h"

/******************************************************************************
* swapInt ()
*
* Arguments: a - item para trocar
b - item para trocar
* Returns: (void)
*
* Description: troca dois itens do tipo integer recebidos
*****************************************************************************/
void swapInt(int *a, int *b){
	int t = *a;
	*a = *b;
	*b = t;
}

/******************************************************************************
* swapDouble()
*
* Arguments: a - item para trocar
b - item para trocar
* Returns: (void)
*
* Description: troca dois itens do tipo double recebidos
*****************************************************************************/
void swapDouble(double *a, double *b){
	double t = *a;
	*a = *b;
	*b = t;
}

/******************************************************************************
* partition() - Insertion Sort
*
* Arguments: st_Mst - estrutura com os elementos para trocar
*            first, last - limites a considerar na tabela
*            function -  indica se vem do quickSort(0) ou partialSort(1)
* Returns: (void)
*
* Description: Algoritmo de ordenacao
*****************************************************************************/
int partitionMST(AirRoutes_Mst *st_Mst, int first, int last){

	int pivot = get_mst2(st_Mst, last);
	int i = (first - 1);
	int j;

	for (j = first; j <= last - 1; j++){
		/*se o elemento presente e menor que o pivot*/
		if (get_mst2(st_Mst, j) < pivot){
			i++; /*incrementa o index do menor elemento*/
			swapInt(&st_Mst->mst[i].airport2, &st_Mst->mst[j].airport2);
			swapDouble(&st_Mst->mst[i].cost, &st_Mst->mst[j].cost);
		}
	}
	swapInt(&st_Mst->mst[i+1].airport2, &st_Mst->mst[last].airport2);
	swapDouble(&st_Mst->mst[i+1].cost, &st_Mst->mst[last].cost);

	return (i+1);
}

/******************************************************************************
* quickSortsort()
*
* Arguments: st_Mst - estrutura que contem os elemntos a ordenar
*            first, last - limites a considerar na tabela
mais especificamente:
first - index do primeiro elemento do vetor a ser ordenado
last - ultimo elemento do array a ser ordenado
*            function - indica se vem do quickSort(0) ou partialSort(1)

* Returns: (void)
*
* Description: Algritmo de ordenacao
*****************************************************************************/
void quickSortMST(AirRoutes_Mst *st_Mst, int first, int last){
	int middle = 0;

	if (first < last){
		middle = partitionMST(st_Mst, first, last);
		quickSortMST(st_Mst, first, middle - 1);
		quickSortMST(st_Mst, middle + 1, last);
	}
}


/******************************************************************************
* partialSort()
*
* Arguments: st_Mst - estrutura que contem os elemntos a ordenar
*            st_Routes - ponteiro para a estrutura onde a informacao vai ser
guardada

* Returns: (void)
*
* Description: Algritmo de ordenacao
*****************************************************************************/
void partialSort(AirRoutes *st_Routes, AirRoutes_Mst *st_Mst){

	int i, j, in = 0, first = 0, last = 0;
	for (i = 1; i < get_nAirport(st_Routes)-1; i++){
		for (j = i+1; j < get_nAirport(st_Routes); j++) {
			if (get_mst1(st_Mst, i) == get_mst1(st_Mst, j)){
				if (in == 0){
					first = i;
					in = 1;
				}
				last = j;
				if(j == get_nAirport(st_Routes)-1){
					quickSortMST(st_Mst, first, last);
					in = 0;
					break;
				}
			}else{
				quickSortMST(st_Mst, first, last);
				in = 0;
				break;
			}
		}
	}
}
