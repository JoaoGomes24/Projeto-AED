#ifndef AIRROUTES_INCLUDED
#define AIRROUTES_INCLUDED

/* estrutura que contem a informacao sobre uma aresta*/
typedef struct AirRoutes_Edge{
  int airport1;
  int airport2;
  double cost;
}AirRoutes_Edge;

/* estrutura que contem informacao sobre os grafos do ficheiro lido*/
typedef struct AirRoutes{
  int nAirports;
  int nRoutes;
  int City;
  int City2;
  int existense;
  char Mode[3];
  AirRoutes_Edge *airports;
} AirRoutes;

/* estrutura que contem a Mst criada */
typedef struct AirRoutes_Mst{
  int *st;
  double *val;
  int count;
  double sum;
  AirRoutes_Edge *mst;
}AirRoutes_Mst;

/* estrutura que contem a Mst criada para o modo B1 */
typedef struct AirRoutes_B1{
  int *mstB1_1;
  int *mstB1_2;
  double *val_B1;
}AirRoutes_B1;

/*estrutura que contem a Mst criada para o modo C1 */
typedef struct AirRoutes_C1{
  int *mstC1_1;
  int *mstC1_2;
  double *val_C1;
}AirRoutes_C1;

/* estrutura que contem a Mst criada para o modo D1*/
typedef struct AirRoutes_D1{
  int *mstD1_1;
  int *mstD1_2;
  double *val_D1;
  int *idx;
}AirRoutes_D1;

/* estrutura que contem a Mst criada para o modo E1 */
typedef struct AirRoutes_E1{
  int *mstE1_1;
  int *mstE1_2;
  double *val_E1;
}AirRoutes_E1;

/*--------------------------------Abstratos.c---------------------------------*/
int get_nAirport(AirRoutes *st_Routes);
int get_nRoutes(AirRoutes *st_Routes);
char *get_Mode(AirRoutes *st_Routes);
int get_City1(AirRoutes *st_Routes);
int get_City2(AirRoutes *st_Routes);
int get_existense(AirRoutes *st_Routes);
double get_adjacency(AirRoutes *st_Routes, int i, int j);
int get_airport1(AirRoutes *st_Routes, int i);
int get_airport2(AirRoutes *st_Routes, int i);
double get_cost(AirRoutes *st_Routes, int i);
int get_st(AirRoutes_Mst *st_Mst, int i);
int get_mst1(AirRoutes_Mst *st_Mst, int i);
int get_mst2(AirRoutes_Mst *st_Mst, int i);
double get_val(AirRoutes_Mst *st_Mst, int i);
int get_count(AirRoutes_Mst *st_Mst);
double get_sum(AirRoutes_Mst *st_Mst);
int get_mstE1_1(AirRoutes_E1 *st_E1, int i);
int get_mstE1_2(AirRoutes_E1 *st_E1, int i);
double get_valE1(AirRoutes_E1 *st_E1, int i);
int get_mstB1_1(AirRoutes_B1 *st_B1, int i);
int get_mstB1_2(AirRoutes_B1 *st_B1, int i);
double get_valB1(AirRoutes_B1 *st_B1, int i);
/*int get_airportB1_1(AirRoutes_B1 *st_B1);
int get_airportB1_2(AirRoutes_B1 *st_B1);
double get_costB1(AirRoutes_B1 *st_B1);
int get_idxE1(AirRoutes_E1 *st_E1);*/
int get_mstC1_1(AirRoutes_C1 *st_C1, int i);
int get_mstC1_2(AirRoutes_C1 *st_C1, int i);
double get_valC1(AirRoutes_C1 *st_C1, int i);
int get_mstD1_1(AirRoutes_D1 *st_D1, int i);
int get_mstD1_2(AirRoutes_D1 *st_D1, int i);
double get_valD1(AirRoutes_D1 *st_D1, int i);
int get_idx(AirRoutes_D1 *st_D1, int i);

/*--------------------------------Sort.c--------------------------------------*/
void swapInt(int *a, int *b);
void swapDouble(double *a, double *b);
int partitionMST(AirRoutes_Mst *st_Mst, int first, int last);
void quickSortMST(AirRoutes_Mst *st_Mst, int first, int last);
int partitionEdges(AirRoutes *st_Routes, int first, int last);
void quickSortEdges(AirRoutes *st_Routes, int first, int last);
void partialSort(AirRoutes *st_Routes, AirRoutes_Mst *st_Mst);

/*---------------------------------ModeA1.c-----------------------------------*/
void FreeMst(AirRoutes_Mst *st_Mst);
AirRoutes_Mst *AllocMst(AirRoutes *st_Routes);
int find(AirRoutes_Mst *st_Mst, int i);
void Union(AirRoutes_Mst *st_Mst, int airport1, int airport2);
void getSum(AirRoutes *st_Routes, AirRoutes_Mst *st_Mst);
void printMST(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst, int Mode);
void ModeA1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst, int Mode);

/*---------------------------------ModeB1.c-----------------------------------*/
void FreeB1(AirRoutes_B1 *st_B1);
AirRoutes_B1 *AllocB1(AirRoutes *st_Routes);
int checkExistenceB1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst);
void printMST_B1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst, AirRoutes_B1 *st_B1, int exist, int Mode);
void ModeB1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst, AirRoutes_E1 *st_E1);

/*---------------------------------ModeC1.c-----------------------------------*/
void FreeC1(AirRoutes_C1 *st_C1);
AirRoutes_C1 *AllocC1(AirRoutes *st_Routes);
int checkExistenceC1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst);
void printMST_C1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst, AirRoutes_C1 *st_C1, int CountA1, double SumA1, int Mode);
void ModeC1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst);

/*-----------------------------------ModeD1.c---------------------------------*/
void FreeD1(AirRoutes_D1 *st_D1);
AirRoutes_D1 *AllocD1(AirRoutes *st_Routes);
void printMST_D1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst, AirRoutes_D1 *st_D1, int connectivity, int Mode);
void ModeD1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst);

/*---------------------------------ModeE1.c-----------------------------------*/
void FreeE1(AirRoutes_E1 *st_E1);
AirRoutes_E1 *AllocE1(AirRoutes *st_Routes);
void ModeE1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst, AirRoutes_E1 *st_E1);

/*---------------------------------AirRoutes.c--------------------------------*/
FILE *open_R_File(char *FileName_R, char *Mode);
void checkExtension(FILE *Read, char *FileName);
FILE *open_W_File(char *FileName_R, char *Mode);
void FreeFiles(FILE *Read, FILE *Write);
void FreeMatrix(AirRoutes *st_Routes);
int CompareCost(const void* airport_A, const void* airport_B);
int CompareAirports(const void* airport_A, const void* airport_B);
int AllocMatrix(FILE *Read, AirRoutes *st_Routes);
void FillMatrix(FILE *Read, AirRoutes *st_Routes);
void checkMode(FILE *Read, FILE *Write, AirRoutes *st_Routes);
int main(int argc, char *argv[]);

#endif // AIRROUTES_INCLUDED
