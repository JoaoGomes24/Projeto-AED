/*****************************************************************************
* File Name: ModeE1.c
*
* SYNOPSIS
*     #include <stdio.h>
*     #include <stdlib.h>
*     #include <string.h>
*     #include <stdbool.h>
*     #include <float.h>
*     #include <limits.h>
*     #include "AirRoutes.h"
*
* DESCRIPTION
*		Corre o algoritmo produzido para o Modo B1 para todas as aretas da Mst
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <float.h>
#include <limits.h>
#include "AirRoutes.h"

/******************************************************************************
* FreeE1()
*
* Arguments: st_E1 - ponteiro que guarda a informacao da Mst criada para o modo B1

* Returns: nao tem

* Description:
*Liberta a Mst criada para o modo E1
*****************************************************************************/
void FreeE1(AirRoutes_E1 *st_E1){

  free(st_E1->mstE1_1);
  free(st_E1->mstE1_2);
  free(st_E1->val_E1);
  free(st_E1);
}

/******************************************************************************
* AllocE1()
*
* Arguments: st_Routes - ponteiro para estrutura que guarda informacao dos grafos

* Returns: estrutura criada para a Mst do modo E1

* Description:
* Aloca a estrutura para a Mst criada para o modo E1
*****************************************************************************/
AirRoutes_E1 *AllocE1(AirRoutes *st_Routes){

  AirRoutes_E1 *st_E1;

  st_E1 = (AirRoutes_E1 *)calloc(1, sizeof(AirRoutes_E1));
  if (st_E1 == NULL){
    exit(0);
  }
  st_E1->mstE1_1 = (int*)calloc(get_nAirport(st_Routes)+1, sizeof(int));
  if (st_E1->mstE1_1 == NULL){
    exit (0);
  }
  st_E1->mstE1_2 = (int*)calloc(get_nAirport(st_Routes)+1, sizeof(int));
  if (st_E1->mstE1_2 == NULL){
    exit (0);
  }
  st_E1->val_E1 = (double*)calloc(get_nAirport(st_Routes)+1, sizeof(double));
  if (st_E1->val_E1 == NULL){
    exit (0);
  }
  return st_E1;
}

/******************************************************************************
* ModeE1()
*
* Arguments: st_Routes -ponteiro para estrutura que guarda informacao dos grafos
             st_Mst - ponteiro para estrutura que guarda informacao da Mst
             Write - ponteiro para o ficheiro de saida
             st_E1 - ponteiro que guarda a informacao da Mst criada para o modo E1
* Returns: nao tem

* Description:
* Começa por imprimir o cabecalho do ficheiro.No primeiro ciclo, atribui os valores
 das variaveis da Mst do modo A1 as variaveis do modo E1. No segundo ciclo,
 coloca os vertices que formam a rota a interditar em City e City2. De seguida imprime esssas variaveis
 e volta a chamar o modo B1.
*****************************************************************************/
void ModeE1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst, AirRoutes_E1 *st_E1){
  int i;

  fprintf(Write, "%d %d %s %d %.2lf\n", get_nAirport(st_Routes), get_nRoutes(st_Routes), get_Mode(st_Routes), get_count(st_Mst), get_sum(st_Mst));

  for (i = 1; i < get_nAirport(st_Routes); i++) {
    st_E1->mstE1_1[i] = get_mst1(st_Mst, i);
    st_E1->mstE1_2[i] = get_mst2(st_Mst, i);
    st_E1->val_E1[i] = get_val(st_Mst, i);
  }
  for (i = 1; i < get_nAirport(st_Routes); i++){
    if(get_mstE1_1(st_E1, i) != 0){
      st_Routes->City = get_mstE1_1(st_E1, i);
      st_Routes->City2 = get_mstE1_2(st_E1, i);
      fprintf(Write, "%d %d %.2lf ", get_mstE1_1(st_E1, i), get_mstE1_2(st_E1, i), get_valE1(st_E1, i));
      ModeB1(Write, st_Routes, st_Mst, st_E1);
    }
  }
  fprintf(Write, "\n");
}
