/*****************************************************************************
* File Name: ModeD1.c
*
* SYNOPSIS
*     #include <stdio.h>
*     #include <stdlib.h>
*     #include <string.h>
*     #include <stdbool.h>
*     #include <float.h>
*     #include <limits.h>
*     #include "AirRoutes.h"
*
* DESCRIPTION
*		Coloca todas as arestas com um vertice igual ao do cabecalho a 0,
*   e corre o algoritmo de Kruskal de novo(ModoA1) criando uma nova Mst
*   sem o vertice interditado
*
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <float.h>
#include <limits.h>
#include "AirRoutes.h"

/******************************************************************************
* FreeD1()
*
* Arguments: st-D1 - ponteiro que guarda a informacao da Mst criada para o modo D1
*
* Returns: nao tem
*
* Description:
*   Liberta a Mst criada para o modo D1
*****************************************************************************/
void FreeD1(AirRoutes_D1 *st_D1){

  free(st_D1->mstD1_1);
  free(st_D1->mstD1_2);
  free(st_D1->val_D1);
  free(st_D1->idx);
  free(st_D1);
}

/******************************************************************************
* AllocD1()
*
* Arguments: st_Routes - ponteiro para estrutura que guarda informacao dos grafos
*
* Returns: Estrutura para Mst criada no modo D1
*
* Description:
* Aloca a estrutura para a Mst criada para o modo D1
*****************************************************************************/
AirRoutes_D1 *AllocD1(AirRoutes *st_Routes){

  AirRoutes_D1 *st_D1;

  st_D1 = (AirRoutes_D1 *)calloc(1, sizeof(AirRoutes_D1));
  if (st_D1 == NULL){
    exit(0);
  }
  st_D1->mstD1_1 = (int*)calloc(get_nAirport(st_Routes)+1, sizeof(int));
  if (st_D1->mstD1_1 == NULL){
    exit (0);
  }
  st_D1->mstD1_2 = (int*)calloc(get_nAirport(st_Routes)+1, sizeof(int));
  if (st_D1->mstD1_2 == NULL){
    exit (0);
  }
  st_D1->val_D1 = (double*)calloc(get_nAirport(st_Routes)+1, sizeof(double));
  if (st_D1->val_D1 == NULL){
    exit (0);
  }
  st_D1->idx = (int*)calloc(get_nAirport(st_Routes)+1, sizeof(int));
  if (st_D1->idx == NULL){
    exit (0);
  }
  return st_D1;
}

/******************************************************************************
* printMST_D1()
*
* Arguments:Write - ponteiro para o ficheiro de saida
            st_Routes - ponteiro para estrutura que guarda informacao dos grafos
            st_Mst - ponteiro para estrutura que guarda informacao da Mst
            st_D1 - ponteiro que guarda a informacao da Mst criada para o modo D1
            connectivity - inteiro que refere a connectividade (0 caso não se mantenha), 1 caso se mantenha
             Mode - caso seja 0, faz print da  Mst vinda do modo A1. Caso seja 1,
              faz print da Mst previamente guardada st_B1
* Returns: nao tem

* Description:
* Imprime a Mst do modo D1
*****************************************************************************/
void printMST_D1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst, AirRoutes_D1 *st_D1, int connectivity, int Mode){
  int j;

  if(Mode == 1){
    fprintf(Write, "%d %d %s %d %d %.2lf %d\n", get_nAirport(st_Routes), get_nRoutes(st_Routes), get_Mode(st_Routes), get_City1(st_Routes), get_count(st_Mst), get_sum(st_Mst), connectivity);
    for (j = 1; j < get_nAirport(st_Routes); j++) {
      if(get_mstD1_1(st_D1, j) != 0){
        fprintf(Write, "%d %d %.2lf\n", get_mstD1_1(st_D1, j), get_mstD1_2(st_D1, j), get_valD1(st_D1, j));
      }
    }
  }
  if(Mode == 0){
    for (j = 1; j < get_nAirport(st_Routes); j++) {
      if(get_mst1(st_Mst, j) != 0 && get_val(st_Mst, j) != 0){
        fprintf(Write, "%d %d %.2lf\n", get_mst1(st_Mst, j), get_mst2(st_Mst, j), get_val(st_Mst, j));
      }
    }
  }
}

/******************************************************************************
* ModeD1()
*
* Arguments: st_Routes - ponteiro para estrutura que guarda informacao dos grafos
*            st_Mst - ponteiro para estrutura que guarda informacao da Mst
*            Write - ponteiro para o ficheiro de saida
*
* Returns: nao tem

* Description:
* Coloca todas as arestas com um vertice igual ao do cabecalho a 0,
* e corre o algoritmo de Kruskal de novo(ModoA1)
*****************************************************************************/
void ModeD1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst){

  AirRoutes_D1 *st_D1;
  int i, j, z = 0, connectivity = 0, count = 0;

  if((get_City1(st_Routes) >= 1 && get_City1(st_Routes) <= get_nAirport(st_Routes))){

    st_D1 = AllocD1(st_Routes);

    for (i = 1; i < get_nAirport(st_Routes); i++) {
      st_D1->mstD1_1[i] = get_mst1(st_Mst, i);
      st_D1->mstD1_2[i] = get_mst2(st_Mst, i);
      st_D1->val_D1[i] = get_val(st_Mst, i);
    }

    for (i = 0; i < get_nRoutes(st_Routes); i++) {
      if((get_airport1(st_Routes, i) == get_City1(st_Routes)) || (get_airport2(st_Routes, i) == get_City1(st_Routes))){
        st_Routes->airports[i].airport1 = 0;
        st_Routes->airports[i].airport2 = 0;
        st_Routes->airports[i].cost = 0.0;
      }
    }

    ModeA1(Write, st_Routes, st_Mst, 0);
    for (i = 1; i < get_nAirport(st_Routes); i++) {
      for (j = 1; j < get_nAirport(st_Routes); j++) {
        if((get_mst1(st_Mst, i) == get_mstD1_1(st_D1, j)) && (get_mst2(st_Mst, i) == get_mstD1_2(st_D1, j))){
          break;
        }
        if((j == get_nAirport(st_Routes)-1) && (get_val(st_Mst, i) != 0)){
          connectivity = 1;
          count++;
          st_D1->idx[z++] = i;
          break;
        }
      }
    }
    if(count != 0){
      printMST_D1(Write, st_Routes, st_Mst, st_D1, count, 1);
      for (i = 0; i < count; i++) {
        z = get_idx(st_D1, i);
        fprintf(Write, "%d %d %.2lf\n", get_mst1(st_Mst, z), get_mst2(st_Mst, z), get_val(st_Mst, z));
      }
    }

    if (connectivity == 0) {
      printMST_D1(Write, st_Routes, st_Mst, st_D1, connectivity, 1);
    }
    fprintf(Write, "\n");
    FreeD1(st_D1);
  }else{
    fprintf(Write, "%d %d %s %d %d %.2lf %d\n", get_nAirport(st_Routes), get_nRoutes(st_Routes), get_Mode(st_Routes), get_City1(st_Routes), get_count(st_Mst), get_sum(st_Mst), -1);
    printMST_D1(Write, st_Routes, st_Mst, NULL, 0, 0);
    fprintf(Write, "\n");
  }
  return;
}
