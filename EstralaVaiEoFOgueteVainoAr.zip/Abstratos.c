#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "AirRoutes.h"

int get_nAirport(AirRoutes *st_Routes){
  return st_Routes->nAirports;
}

int get_nRoutes(AirRoutes *st_Routes){
  return st_Routes->nRoutes;
}

char *get_Mode(AirRoutes *st_Routes){
  return st_Routes->Mode;
}

int get_City1(AirRoutes *st_Routes){
  return st_Routes->City;
}

int get_City2(AirRoutes *st_Routes){
  return st_Routes->City2;
}

int get_existense(AirRoutes *st_Routes){
  return st_Routes->existense;
}

int get_airport1(AirRoutes *st_Routes, int i){
  return st_Routes->airports[i].airport1;
}

int get_airport2(AirRoutes *st_Routes, int i){
  return st_Routes->airports[i].airport2;
}

double get_cost(AirRoutes *st_Routes, int i){
  return st_Routes->airports[i].cost;
}

int get_st(AirRoutes_Mst *st_Mst, int i){
  return st_Mst->st[i];
}

int get_mst1(AirRoutes_Mst *st_Mst, int i){
  return st_Mst->mst[i].airport1;
}

int get_mst2(AirRoutes_Mst *st_Mst, int i){
  return st_Mst->mst[i].airport2;
}

double get_val(AirRoutes_Mst *st_Mst, int i){
  return st_Mst->mst[i].cost;
}

int get_count(AirRoutes_Mst *st_Mst){
  return  st_Mst->count;
}

double get_sum(AirRoutes_Mst *st_Mst){
  return  st_Mst->sum;
}

int get_mstB1_1(AirRoutes_B1 *st_B1, int i){
  return st_B1->mstB1_1[i];
}

int get_mstB1_2(AirRoutes_B1 *st_B1, int i){
  return st_B1->mstB1_2[i];
}

double get_valB1(AirRoutes_B1 *st_B1, int i){
  return st_B1->val_B1[i];
}

int get_mstC1_1(AirRoutes_C1 *st_C1, int i){
  return st_C1->mstC1_1[i];
}

int get_mstC1_2(AirRoutes_C1 *st_C1, int i){
  return st_C1->mstC1_2[i];
}

double get_valC1(AirRoutes_C1 *st_C1, int i){
  return st_C1->val_C1[i];
}

int get_mstD1_1(AirRoutes_D1 *st_D1, int i){
  return st_D1->mstD1_1[i];
}

int get_mstD1_2(AirRoutes_D1 *st_D1, int i){
  return st_D1->mstD1_2[i];
}

double get_valD1(AirRoutes_D1 *st_D1, int i){
  return st_D1->val_D1[i];
}

int get_idx(AirRoutes_D1 *st_D1, int i){
  return st_D1->idx[i];
}

int get_mstE1_1(AirRoutes_E1 *st_E1, int i){
  return st_E1->mstE1_1[i];
}

int get_mstE1_2(AirRoutes_E1 *st_E1, int i){
  return st_E1->mstE1_2[i];
}

double get_valE1(AirRoutes_E1 *st_E1, int i){
  return st_E1->val_E1[i];
}
