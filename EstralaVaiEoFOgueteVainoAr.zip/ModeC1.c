/*******************************************************************************
* File Name: ModeC1.c
*
* SYNOPSIS
*     #include <stdio.h>
*     #include <stdlib.h>
*     #include <string.h>
*     #include <stdbool.h>
*     #include <float.h>
*     #include <limits.h>
*     #include "AirRoutes.h"
*
* DESCRIPTION
*   Coloca a aresta recebida do cabecalho caso exista a 0
*   e corre o algoritmo de Kruskal de novo(ModoA1), cria uma nova Mst sem
*   a aresta interditada, neste modo a nova Mst nao precisa de ter todas
*   as rotas da Mst original
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <float.h>
#include <limits.h>
#include "AirRoutes.h"

/******************************************************************************
* FreeC1()
*
* Arguments: st-C1 - ponteiro para a estrutura que guarda a informacao da Mst
                    criada para o modo C1

* Returns: nao tem

* Description:
*Liberta a Mst criada para o modo C1
*****************************************************************************/
void FreeC1(AirRoutes_C1 *st_C1){

  free(st_C1->mstC1_1);
  free(st_C1->mstC1_2);
  free(st_C1->val_C1);
  free(st_C1);
}

/******************************************************************************
* AllocC1()
*
* Arguments: st_Routes - ponteiro para estrutura que guarda informacao dos grafos

* Returns: st_C1

* Description:
*Aloca a estrutura para a Mst criada para o modo C1
*****************************************************************************/
AirRoutes_C1 *AllocC1(AirRoutes *st_Routes){

  AirRoutes_C1 *st_C1;

  st_C1 = (AirRoutes_C1 *)calloc(1, sizeof(AirRoutes_C1));
  if (st_C1 == NULL){
    exit(0);
  }
  st_C1->mstC1_1 = (int*)calloc(get_nAirport(st_Routes)+1, sizeof(int));
  if (st_C1->mstC1_1 == NULL){
    exit (0);
  }
  st_C1->mstC1_2 = (int*)calloc(get_nAirport(st_Routes)+1, sizeof(int));
  if (st_C1->mstC1_2 == NULL){
    exit (0);
  }
  st_C1->val_C1 = (double*)calloc(get_nAirport(st_Routes)+1, sizeof(double));
  if (st_C1->val_C1 == NULL){
    exit (0);
  }
  return st_C1;
}

/******************************************************************************
* checkExistenceC1()
*
* Arguments: st_Routes -  ponteiro para estrutura que guarda informacao dos grafos
             st_Mst -ponteiro para estrutura que guarda informacao da Mst
             Write - ponteiro para o ficheiro de saida
* Returns: exist

* Description:
* Verifica a existencia da rota interditada. Caso nao pertenca, imprimimos -1
*****************************************************************************/
int checkExistenceC1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst){
  int i, exist = 0;

  for (i = 1; i < get_nAirport(st_Routes); i++) {
    if(get_mst1(st_Mst, i) != 0){
      if (((get_mst1(st_Mst, i) == get_City1(st_Routes)) && (get_mst2(st_Mst, i) == get_City2(st_Routes))) || ((get_mst2(st_Mst, i) == get_City1(st_Routes)) && (get_mst1(st_Mst, i) == get_City2(st_Routes)))){
        exist = 1;
      }
    }
  }
  if (exist == 0) {
    return -1;
  }
  return exist;
}

/******************************************************************************
* printMST_C1()
*
* Arguments: st_Routes -ponteiro para estrutura que guarda informacao dos grafos
             st_Mst - ponteiro para estrutura que guarda informacao da Mst
             Mode -caso seja 0, faz print da  Mst vinda do modo A1. Caso seja 1,
              faz print da Mst previamente guardada st_C1
             st_C1 - ponteiro para a estrutura que guarda a informacao da Mst
             criada para o modo C1
             CountA1 - mantem a contagem de arestas da Mst do modo A1
             SumA1 -mantem o custo da Mst criada no modo A1
             Write - ponteiro para o ficheiro de saida
* Returns: nao tem

* Description:
* Imprime  a Mst do modo C1
*****************************************************************************/
void printMST_C1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst, AirRoutes_C1 *st_C1, int CountA1, double SumA1, int Mode){
  int j;

  if(Mode == 1){
    fprintf(Write, "%d %d %s %d %d %d %.2lf %d %.2lf\n", get_nAirport(st_Routes), get_nRoutes(st_Routes), get_Mode(st_Routes), get_City1(st_Routes), get_City2(st_Routes), CountA1, SumA1, get_count(st_Mst), get_sum(st_Mst));
    for (j = 1; j < get_nAirport(st_Routes); j++) {
      if(get_mstC1_1(st_C1, j) != 0){
        fprintf(Write, "%d %d %.2lf\n", get_mstC1_1(st_C1, j), get_mstC1_2(st_C1, j), get_valC1(st_C1, j));
      }
    }
  }
  for (j = 1; j < get_nAirport(st_Routes); j++) {
    if((get_mst1(st_Mst, j) != 0 && get_val(st_Mst, j) != 0) && get_val(st_Mst, j) != get_val(st_Mst, j-1)){
      fprintf(Write, "%d %d %.2lf\n", get_mst1(st_Mst, j), get_mst2(st_Mst, j), get_val(st_Mst, j));
    }
  }

  fprintf(Write, "\n");/* inclusao de linha em branco entre Mst`s */
}

/******************************************************************************
* ModeC1()
*
* Arguments: st_Routes - ponteiro para estrutura que guarda informacao dos grafos
             st_Mst -ponteiro para estrutura que guarda informacao da Mst
             Write - ponteiro para o ficheiro de saida
* Returns: nao tem

* Description:
*Coloca a aresta recebida do cabecalho, caso exista, a 0 e core o algoritmo de
 Kruskal de novo (modo A1).
*****************************************************************************/
void ModeC1(FILE *Write, AirRoutes *st_Routes, AirRoutes_Mst *st_Mst){

  AirRoutes_C1 *st_C1;
  int i, exist, CountA1 = st_Mst->count;
  double SumA1 = st_Mst->sum;

  if((get_City1(st_Routes) >= 1 && get_City1(st_Routes) <= get_nAirport(st_Routes)) && (get_City2(st_Routes) >= 1 && get_City2(st_Routes) <= get_nAirport(st_Routes))){
    if(get_existense(st_Routes) != 1){
      fprintf(Write, "%d %d %s %d %d %d %.2lf %d\n", get_nAirport(st_Routes), get_nRoutes(st_Routes), get_Mode(st_Routes), get_City1(st_Routes), get_City2(st_Routes), get_count(st_Mst), get_sum(st_Mst), -1);
      printMST_C1(Write, st_Routes, st_Mst, NULL, CountA1, SumA1, 0);
      return;
    }

    exist = checkExistenceC1(Write, st_Routes, st_Mst);
    if(exist == -1){
      fprintf(Write, "%d %d %s %d %d %d %.2lf %d\n", get_nAirport(st_Routes), get_nRoutes(st_Routes), get_Mode(st_Routes), get_City1(st_Routes), get_City2(st_Routes), get_count(st_Mst), get_sum(st_Mst), -1);
      printMST_C1(Write, st_Routes, st_Mst, NULL, CountA1, SumA1, 0);
      return;
    }

    st_C1 = AllocC1(st_Routes);

    for (i = 1; i < get_nAirport(st_Routes); i++) {
      st_C1->mstC1_1[i] = get_mst1(st_Mst, i);
      st_C1->mstC1_2[i] = get_mst2(st_Mst, i);
      st_C1->val_C1[i] = get_val(st_Mst, i);
    }

    for (i = 0; i < get_nRoutes(st_Routes); i++) {
      if((get_airport1(st_Routes, i) == get_City1(st_Routes) && get_airport2(st_Routes, i) == get_City2(st_Routes)) || (get_airport2(st_Routes, i) == get_City1(st_Routes) && get_airport1(st_Routes, i) == get_City2(st_Routes))){
        st_Routes->airports[i].airport1 = 0;
        st_Routes->airports[i].airport2 = 0;
        st_Routes->airports[i].cost = 0.0;
        break;
      }
    }
    st_Mst->count = 0;
    st_Mst->sum = 0.0;

    ModeA1(Write, st_Routes, st_Mst, 1);
    printMST_C1(Write, st_Routes, st_Mst, st_C1, CountA1, SumA1, 1);
    FreeC1(st_C1);
  }else{
    fprintf(Write, "%d %d %s %d %d %d %.2lf %d\n", get_nAirport(st_Routes), get_nRoutes(st_Routes), get_Mode(st_Routes), get_City1(st_Routes), get_City2(st_Routes), get_count(st_Mst), get_sum(st_Mst), -1);
    printMST_C1(Write, st_Routes, st_Mst, NULL, CountA1, SumA1, 0);
  }
  return;
}
