/*
===============================================================================
Nome do programa: AirRoutes
Projeto para a UC de Algoritmos e Estruturas de Dados do curso de MEEC do
IST 2020/2021 2 Ano 1 Semestre

Este programa tem como objetivo ter a capacidade de produzir um conjunto de
rotas ligando aeroportos que garanta a existencia de um caminho entre cada par
fonte/destino sem qualquer redundância.

Ficheiros:
(1)AirRoutes.c - ficheiro que contem o main program
(2)DataAnalysis.c - ficheiro que analisa e prepara os dados
(3)Abstratos.c - ficheiro que contem os abstratos
(4)Sort.c - ficheiro que contem algoritmos de ordenacao
(5)ModeA1.c - ficheiro que contem a resolucao do Modo A1
(6)ModeB1.c - ficheiro que contem a resolucao do Modo B1
(7)ModeC1.c - ficheiro que contem a resolucao do Modo C1
(8)ModeD1.c - ficheiro que contem a resolucao do Modo D1
(9)ModeE1.c - ficheiro que contem a resolucao do Modo E1

Autores: Joao Gomes - 96248
Tiago Franco - 96333                                  Data: 20/11/2020
===============================================================================
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <float.h>
#include <limits.h>
#include "AirRoutes.h"

/******************************************************************************
* open_R_File()
*
* Arguments: FileName_R -  nome para o ficheiro de entrada
*            Mode - vetor de chars (string) que guarda o modo a analisar

* Returns: Read
*
* Description:
*   Abre o ficheiro de leitura e retorna o seu ponteiro
*****************************************************************************/
FILE *open_R_File(char *FileName_R, char *Mode){

  FILE *Read = NULL;

  Read = fopen(FileName_R, Mode);
  if (Read == NULL) {
    exit (0);
  }
  return Read;
}

/******************************************************************************
* checkExtension()
*
* Arguments: Write - ponteiro para o ficheiro de saida
*            FileName - nome completo do ficheiro

* Returns: nao tem
*
* Description:
*   recebe como argumento o nome do ficheiro e verifica se este tem a extensao
*   valida, caso contrario, o programa termina
*****************************************************************************/
void checkExtension(FILE *Read, char *FileName){

  char WantedExtension_R[] = ".routes", ch = '.', *ReadExtension;

  if(FileName != NULL){
    if(strcmp((ReadExtension = strrchr(FileName, ch)), WantedExtension_R) != 0 ){
      fclose(Read);
      exit(0);
    }
  }
}

/******************************************************************************
* open_W_File()
*
* Arguments: FileName_R - nome do ficheiro de entrada
*            Mode - vetor de chars (string) que guarda o modo a analisar

* Returns: Write
*
* Description:
*   Procede-se a mudança da extensao do ficheiro de entrada para a extensao
*   do ficheiro de saida. De seguida abre-se o ficheiro de escrita com o
*   nome correto e retorna o seu ponteiro
*****************************************************************************/
FILE *open_W_File(char *FileName_R, char *Mode){

  FILE *Write = NULL;
  char *FileName_W = NULL, *WantedExtension_W = ".bbones", *WantedExtension_R = ".routes";
  int len_FileName = 0, len_WritingFile = 0, i = 0;

  len_FileName = strlen(FileName_R) - strlen(WantedExtension_R); /*ver o tamanho antes da extensao*/
  len_WritingFile = len_FileName + strlen(WantedExtension_W);

  FileName_W = (char*)calloc((len_WritingFile+1), sizeof(char));
  if(FileName_W == NULL){
    exit(0);
  }

  while (i < len_FileName){
    FileName_W[i] = FileName_R[i];
    i++;
  }
  strcat(FileName_W, WantedExtension_W);/*troca de extensao do ficheiro de entrada para o de saida*/

  Write = fopen(FileName_W, Mode);
  if (Write == NULL) {
    exit (0);
  }
  free(FileName_W);
  return Write;
}

/******************************************************************************
* FreeFiles()
*
* Arguments: Read - ponteiro para o ficheiro de entrada
Write - ponteiro para o ficheiro de saida
*

* Returns: nao tem
*
* Description:
*   liberta os ponteiros que contem os ficheiros
*****************************************************************************/
void FreeFiles(FILE *Read, FILE *Write){

  fclose(Read);
  fclose(Write);
}

/******************************************************************************
* FreeMatrix()
*
* Arguments: st_Routes - ponteiro para estrutura que guarda informacao dos grafos

* Returns: nao tem

* Description:
*   liberta o vetor de arestas
*****************************************************************************/
void FreeMatrix(AirRoutes *st_Routes){

  free(st_Routes->airports);
  return;
}

/******************************************************************************
*AllocWordTable()
*
* Arguments: Read - ponteiro para o ficheiro de entrada
*            st_Routes - ponteiro para estrutura que guarda informacao dos grafos

* Returns: exit status
*
* Description:
*   le do ficheiro de entrada o cabecalho do grafo, aloca o vetor de arestas
*****************************************************************************/
int AllocMatrix(FILE *Read, AirRoutes *st_Routes){

  if((fscanf(Read,"%d %d %s", &st_Routes->nAirports, &st_Routes->nRoutes, st_Routes->Mode)) != 3){
    return 1;
  }
  if (((strcmp(st_Routes->Mode, "B1")) == 0) || ((strcmp(st_Routes->Mode, "C1")) == 0) || ((strcmp(st_Routes->Mode, "D1")) == 0)) {
    if((fscanf(Read,"%d", &st_Routes->City)) != 1){
      return 1;
    }
  }
  if(((strcmp(st_Routes->Mode, "B1")) == 0) || ((strcmp(st_Routes->Mode, "C1")) == 0)){
    if((fscanf(Read,"%d", &st_Routes->City2)) != 1){
      return 1;
    }
  }

  st_Routes->airports = (AirRoutes_Edge*) calloc(get_nRoutes(st_Routes)+1, sizeof(AirRoutes_Edge));
  if (st_Routes->airports == NULL) {
    exit (0);
  }
  return 0;
}

/******************************************************************************
* CompareCost()
*
* Arguments: airport_A - ponteiro para estrutura que contem uma aresta do vetor
*            airport_B - ponteiro para estrutura que contem uma aresta do vetor

* Returns: int
*
* Description:
*  Compara duas arestas de acordo com o seu custo
*  Usado para ordenar na função qsort()
*****************************************************************************/
int CompareCost(const void* airport_A, const void* airport_B){
  AirRoutes_Edge* airport1 = (AirRoutes_Edge*)airport_A;
  AirRoutes_Edge* airport2 = (AirRoutes_Edge*)airport_B;
	return airport1->cost > airport2->cost;
}

/******************************************************************************
* CompareAirports()
*
* Arguments: airport_A - ponteiro para estrutura que contem uma aresta do vetor
*            airport_B - ponteiro para estrutura que contem uma aresta do vetor

* Returns: int
*
* Description:
*  Compara duas arestas de acordo com o número do seu aeroporto
*  Usado para ordenar na função qsort()
*****************************************************************************/
int CompareAirports(const void* airport_A, const void* airport_B){
  AirRoutes_Edge* airport1 = (AirRoutes_Edge*)airport_A;
  AirRoutes_Edge* airport2 = (AirRoutes_Edge*)airport_B;
	return airport1->airport1 > airport2->airport1;
}

/******************************************************************************
* FillMatrix()
*
* Arguments: Read - ponteiro para o ficheiro de entrada
*            st_Routes - ponteiro para estrutura que guarda informacao dos grafos

* Returns: nao tem
*
* Description:
*   le os dados do ficheiro e coloca-os no vetor de arestas
*   Coloca os aeroportos ordenados no vetor
*****************************************************************************/
void FillMatrix(FILE *Read, AirRoutes *st_Routes){
  int i = 0, var1 = 0, var2 = 0;
  st_Routes->existense = 0;

  while (i < get_nRoutes(st_Routes)){
    if((fscanf(Read, "%d %d %lf", &st_Routes->airports[i].airport1, &st_Routes->airports[i].airport2, &st_Routes->airports[i].cost)) != 3){
      exit(0);
    }
    if(get_airport1(st_Routes, i) > get_airport2(st_Routes, i)){
      var1 = get_airport1(st_Routes, i);
      var2 = get_airport2(st_Routes, i);
      st_Routes->airports[i].airport1 = var2;
      st_Routes->airports[i].airport2 = var1;
    }
    if (((strcmp(st_Routes->Mode, "B1")) == 0) || ((strcmp(st_Routes->Mode, "C1")) == 0)) {
      if((get_airport1(st_Routes, i) == get_City1(st_Routes) && get_airport2(st_Routes, i) == get_City2(st_Routes)) || (get_airport2(st_Routes, i) == get_City1(st_Routes) && get_airport1(st_Routes, i) == get_City2(st_Routes))){
        st_Routes->existense = 1;
      }
    }
    i++;
  }
  qsort(st_Routes->airports, get_nRoutes(st_Routes), sizeof(st_Routes->airports[0]), CompareCost);

  return;
}

/******************************************************************************
* checkMode()
*
* Arguments: Read - ponteiro para o ficheiro de entrada
*            Write - ponteiro para o ficheiro de saida
st_Routes -

* Returns: nao tem
*
* Description:
*   Com base no ficheiro recebido, verifica o modo que sera escolhido
*   para analisar os grafos
*****************************************************************************/
void checkMode(FILE *Read, FILE *Write, AirRoutes *st_Routes){

  AirRoutes_E1 *st_E1 = NULL;
  AirRoutes_Mst *st_Mst = NULL;

  while (1){
    st_Mst = AllocMst(st_Routes);
    if(strcmp(get_Mode(st_Routes), "A1") == 0){
      ModeA1(Write, st_Routes, st_Mst, 1);
    }else if (strcmp(get_Mode(st_Routes), "B1") == 0){
      ModeA1(Write, st_Routes, st_Mst, 1);
      ModeB1(Write, st_Routes, st_Mst, NULL);
    }else if (strcmp(get_Mode(st_Routes), "C1") == 0){
      ModeA1(Write, st_Routes, st_Mst, 1);
      ModeC1(Write, st_Routes, st_Mst);
    }else if (strcmp(get_Mode(st_Routes), "D1") == 0){
      ModeA1(Write, st_Routes, st_Mst, 1);
      ModeD1(Write, st_Routes, st_Mst);
    }else if (strcmp(get_Mode(st_Routes), "E1") == 0){
      ModeA1(Write, st_Routes, st_Mst, 1);
      st_E1 = AllocE1(st_Routes);
      ModeE1(Write, st_Routes, st_Mst, st_E1);
      FreeE1(st_E1);
    }
    FreeMst(st_Mst);
    FreeMatrix(st_Routes);
    if((AllocMatrix(Read, st_Routes)) == 1){
      break;
    }
    st_Routes->existense = 0;
    FillMatrix(Read, st_Routes);
  }
  return;
}

/******************************************************************************
* main()
*
* Arguments: argc - contador do numero (inteiro) de argumentos passados quando
*            se chama o programa
*            argv -  ponteiro para vetor de strings que contem os argumentos

* Returns: int status
*
*Description:
*   Main Program
*****************************************************************************/
int main(int argc, char *argv[]){

  FILE *Read, *Write;
  AirRoutes st_Routes;

  if(argc == 2){
    Read = open_R_File(argv[1], "r");
    checkExtension(Read, argv[1]);
    AllocMatrix(Read, &st_Routes);
    FillMatrix(Read, &st_Routes);
    Write = open_W_File(argv[1], "w");
    checkMode(Read, Write, &st_Routes);
    FreeFiles(Read, Write);
  }else{
    exit(0);
  }

  return 0;
}
